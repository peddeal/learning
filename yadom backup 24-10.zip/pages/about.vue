<template>
  <v-container class="pa-4 pa-md-8" max-width="1000">

    <v-sheet 
      color="cream-medium" 
      class="pa-6 pa-md-10 mb-10 rounded-lg elevation-4"
    >
      <v-row align="center" justify="space-between">
        <v-col cols="12" md="6">
          <h1 class="text-h4 text-md-h3 mb-4 font-montserrat text-hom-thai-primary">
            Hom Thai
          </h1>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #444;">
            “Hom Thai” was born from a group of students passionate about Thai herbs and inhaler products. However, due to each member’s preference for different scents, the team conducted a consumer survey (2025) and experimented by blending herbs from each person’s inhaler, resulting in a new and intriguing fragrance. The initial concept was: <br></br><strong>“Why not create an inhaler where you can design your own scent and choose your preferred herbs”</strong>
          </p>
        </v-col>
        <v-col cols="12" md="5">
          <v-img 
            src="../public/logo.jpg" 
            alt="หอมไทย" 
           
            class="rounded-lg elevation-2"
            contain
          ></v-img>
        </v-col>
      </v-row>
    </v-sheet>

    <v-row class="mb-10">
      <v-col cols="12" md="6">
        <v-sheet 
          color="cream-light" 
          class="pa-6 pa-md-8 rounded-lg h-100 elevation-2"
        >
          <h2 class="text-h5 mb-4 font-montserrat text-hom-thai-primary">Corporate Mission </h2>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #555;">
            ChatGPT said:

“Hom Thai” focuses on producing high-quality herbal inhalers that are reasonably priced and come in reliable packaging. The brand aims to meet diverse consumer needs, promote physical and mental well-being, and expand its market to an international level.
          </p>
          <v-divider class="my-6"></v-divider>
          <h2 class="text-h5 mb-4 font-montserrat text-hom-thai-primary">Corporate Vision </h2>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #555;">
            “Hom Thai” aims to become the leading herbal inhaler brand in Asia within the next five years.
          </p>
        </v-sheet>
      </v-col>

      <v-col cols="12" md="6">
        <v-sheet 
          color="cream-medium" 
          class="pa-6 pa-md-8 rounded-lg h-100 elevation-2 d-flex flex-column"
        >
          <h2 class="text-h5 text-center mb-5 font-montserrat text-hom-thai-primary">Corporate Values </h2>
          <v-list class="transparent-list" dense>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-lightbulb-on-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Creative Initiative:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">Innovative thinking and creating valuable new ideas.
</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-handshake-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Teamwork & Cooperation:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">Collaboration to achieve goals.
</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-shield-check-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Integrity:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">Integrity and adherence to principles.
</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-rocket-launch-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Achievement Orientation:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">Driven to achieve success.
</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item>
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-star-four-points-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Excellence:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">Continuous quality improvement.
</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
          </v-list>
        </v-sheet>
      </v-col>
    </v-row>

    <v-sheet 
      color="cream-medium" 
      class="pa-6 pa-md-10 mb-10 rounded-lg elevation-4"
    >
      <v-row align="center">
        <v-col cols="12" md="6">
          <h2 class="text-h5 text-md-h4 mb-4 font-montserrat text-hom-thai-primary">
            Our Strength
          </h2>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #444;">
         We differentiate ourselves from competitors by offering customers the option to customize the scent and packaging of our products according to their preferences. We don’t just sell a product—we provide an experience and a story that customers actively participate in creating, which increases the product’s emotional value. This approach aligns with modern consumer trends, where people seek products that reflect their individuality and attention to detail.

Additionally, we utilize AI to help customers customize their scents and employ technology to track purchasing behavior. This data is then analyzed to determine strategies for product sales or brand awareness.
          </p>
        </v-col>
        <v-col cols="12" md="6">
          <v-img 
            src="../public/str.jpeg" 
            alt="จุดแข็ง" 
            
            class="rounded-lg elevation-2"
            contain
          ></v-img>
        </v-col>
      </v-row>
    </v-sheet>

  </v-container>
</template>

<script setup>
// ไม่มี logic เพิ่มเติมในตอนนี้
</script>

<style scoped>
/*
  สไตล์ที่กำหนดแบบ scoped จะมีผลเฉพาะใน Component นี้เท่านั้น
  เพื่อให้มั่นใจว่าฟอนต์และสีที่ใช้ใน Theme มีผลทั่วทั้งแอปพลิเคชัน
  ควรจัดการผ่าน Global CSS/SCSS หรือ Nuxt Config
*/

/*
  หากต้องการใช้ฟอนต์ Montserrat, Poppins, Sarabun ต้องแน่ใจว่าได้ตั้งค่า
  Google Fonts module และ Global CSS (assets/main.scss) ตามที่แนะนำไปก่อนหน้านี้แล้ว
*/

.font-montserrat {
  font-family: 'Montserrat', 'Sarabun', sans-serif !important;
}

.font-poppins {
  font-family: 'Poppins', 'Sarabun', sans-serif !important;
}

.font-sarabun {
  font-family: 'Sarabun', sans-serif !important;
}

/* ปรับระยะห่างระหว่าง v-list-item */
.transparent-list .v-list-item {
  background-color: transparent !important; /* ทำให้พื้นหลังโปร่งใส */
  padding-left: 0;
  padding-right: 0;
}

/* เพิ่มความยืดหยุ่นให้ list item content */
.transparent-list .v-list-item-content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

/* แก้ไข gap สำหรับ flexbox ในบางเบราว์เซอร์ */
.d-flex.flex-column.gap-3 > *:not(:last-child) {
  margin-bottom: 1rem; /* ระยะห่างระหว่าง list items */
}
</style>