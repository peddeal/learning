<template>
  <v-sheet 
    color="#AA7B5C"
    class="py-16 text-center"
    style="background-image: url('your-texture-image.png'); background-size: cover;" 
    dark
  >
    <v-container>
      <v-row>
        
        <v-col cols="12" sm="6" md="3">
          <v-icon size="80">mdi-leaf</v-icon>
          <div style="font-size: 28px; font-weight: bold; margin-top: 16px; color: #fff;">
            Natural ingredients
          </div>
          <p style="font-size: 18px; margin-top: 8px; color: #fff;">
            Premium natural ingredients that are more eco-friendly & better for health.
          </p>
        </v-col>

        <v-col cols="12" sm="6" md="3">
          <v-icon size="80">mdi-bottle-tonic-plus-outline</v-icon>
          <div style="font-size: 28px; font-weight: bold; margin-top: 16px; color: #fff;">
            Aromatherapy
          </div>
          <p style="font-size: 18px; margin-top: 8px; color: #fff;">
            Special blend of essential oils that truly helps improve your mood and your mind.
          </p>
        </v-col>

        <v-col cols="12" sm="6" md="3">
          <v-icon size="80">mdi-palette-swatch-outline</v-icon>
          <div style="font-size: 28px; font-weight: bold; margin-top: 16px; color: #fff;">
            Unique Design
          </div>
          <p style="font-size: 18px; margin-top: 8px; color: #fff;">
            Original designs by our creators
          </p>
        </v-col>

        <v-col cols="12" sm="6" md="3">
          <v-icon size="80">mdi-tune</v-icon>
          <div style="font-size: 28px; font-weight: bold; margin-top: 16px; color: #fff;">
            Customize
          </div>
          <p style="font-size: 18px; margin-top: 8px; color: #fff;">
            You can create your own scent with unique  ingredients
          </p>
        </v-col>

      </v-row>
    </v-container>
  </v-sheet>
</template>
