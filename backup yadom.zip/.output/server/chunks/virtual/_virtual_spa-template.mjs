const template = "";

export { template };
//# sourceMappingURL=_virtual_spa-template.mjs.map
