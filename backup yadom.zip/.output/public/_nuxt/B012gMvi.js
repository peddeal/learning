import{_ as e}from"./DlAUqK2U.js";const r={};function t(c,o){return" Hello "}const n=e(r,[["render",t]]);export{n as default};
