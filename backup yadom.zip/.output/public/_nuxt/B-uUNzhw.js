import{G as a}from"./CjPehoYH.js";const r=a("v-spacer","div","VSpacer");export{r as V};
