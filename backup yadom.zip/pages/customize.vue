<template>
  <v-container>
    <h1 class="text-center" id="cust"> 🎋 สร้างยาดมในแบบของคุณ</h1>

    <v-row>
      <v-col
        v-for="(herb, index) in herbs"
        :key="index"
        cols="12"
        md="6"
        lg="4"
      >
        <v-card>
          <v-img
            :src="herb.image"
            height="300px"
            cover
          ></v-img>
          <v-card-title>{{ herb.name }}</v-card-title>
          <v-card-text>
            <v-slider
              v-model="herb.percentage"
              :max="100"
              :step="1"
              color="green"
              thumb-label
              @change="validateTotal"
            ></v-slider>
            <div>สัดส่วน: {{ herb.percentage }}%</div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
<v-alert
      v-if="totalPercentage > 100"
      type="error"
      class="my-4"
    >
      เปอร์เซ็นต์รวมเกิน 100% แล้ว ({{ totalPercentage }}%) กรุณาปรับลด
    </v-alert>

    <v-alert
      v-else
      type="success"
      class="my-4"
    >
      เปอร์เซ็นต์รวม: {{ totalPercentage }}%
    </v-alert>

    <br>
</br>
    <v-btn color="primary" :disabled="totalPercentage !== 100" @click="submitFormula">
      สร้างสูตรยาดม
    </v-btn>

    <div v-if="showResult" class="mt-6">
      <h2>🌿 สูตรยาดมของคุณ:</h2>
      <ul>
        <li v-for="herb in herbs" :key="herb.name" v-if="herb.percentage > 0">
          {{ herb.name }}: {{ herb.percentage }}%
        </li>
      </ul>
    </div>
  </v-container>
</template>

<script setup>
import { ref, computed } from 'vue'

const herbs = ref([
  { name: 'ยูคาลิปตัส', image: 'b1.jpg', percentage: 0 },
  { name: 'อบเชย', image: 'b2.jpg', percentage: 0 },
  { name: 'ลูกกระวาน', image: 'b3.jpg', percentage: 0 },
  { name: 'โป๊ยกั๊ก', image: 'b4.jpg', percentage: 0 },
  { name: 'พริกไทยดำ', image: 'b5.jpg', percentage: 0 },
  { name: 'ถ่านพรู', image: 'b6.jpg', percentage: 0 },
  { name: 'การบูร', image: 'b7.jpg', percentage: 0 },
  { name: 'พิมเสน', image: 'b8.jpg', percentage: 0 },
  { name: 'เมนทอล', image: 'b9.jpg', percentage: 0 },
])

const totalPercentage = computed(() =>
  herbs.value.reduce((sum, herb) => sum + herb.percentage, 0)
)

const showResult = ref(false)

const validateTotal = () => {
  if (totalPercentage.value > 100) {
    showResult.value = false
  }
}

const submitFormula = () => {
  if (totalPercentage.value === 100) {
    showResult.value = true
  }
}
</script>

<style scoped>
h1 {
  margin-bottom: 20px;
}
</style>