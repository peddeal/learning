<template>
  <v-container class="pa-4 pa-md-8" max-width="1000">

    <v-sheet 
      color="cream-medium" 
      class="pa-6 pa-md-10 mb-10 rounded-lg elevation-4"
    >
      <v-row align="center" justify="space-between">
        <v-col cols="12" md="6">
          <h1 class="text-h4 text-md-h3 mb-4 font-montserrat text-hom-thai-primary">
            Hom Thai
          </h1>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #444;">
            “หอมไทย” ถือกำเนิดขึ้นจากกลุ่มนักศึกษาที่มีความหลงใหลในสมุนไพรไทยและผลิตภัณฑ์ยาดม 
            แต่ด้วยความชอบในกลิ่นที่แตกต่างกันของสมาชิก ทางทีมจึงได้สำรวจความคิดเห็นของผู้บริโภค (Survey, 2025) 
            และทดลองผสมสมุนไพรจากยาดมของแต่ละคนจนเกิดกลิ่นใหม่ที่น่าสนใจ 
            แนวคิดเริ่มต้นคือ <strong>"ทำไมเราไม่สร้างยาดมที่สามารถออกแบบกลิ่นและเลือกสรรสมุนไพรได้เอง"</strong>
          </p>
        </v-col>
        <v-col cols="12" md="5">
          <v-img 
            src="../public/logo.jpg" 
            alt="หอมไทย" 
           
            class="rounded-lg elevation-2"
            contain
          ></v-img>
        </v-col>
      </v-row>
    </v-sheet>

    <v-row class="mb-10">
      <v-col cols="12" md="6">
        <v-sheet 
          color="cream-light" 
          class="pa-6 pa-md-8 rounded-lg h-100 elevation-2"
        >
          <h2 class="text-h5 mb-4 font-montserrat text-hom-thai-primary">Corporate Mission (พันธกิจ)</h2>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #555;">
            “หอมไทย” มุ่งเน้นการควบคุมการผลิตยาดมสมุนไพรที่มีคุณภาพ เหมาะสมกับราคาและบรรจุภัณฑ์เชื่อถือได้ 
            โดยตอบสนองความต้องการที่หลากหลายของผู้บริโภค ส่งเสริมสุขภาพกายและใจ และขยายตลาดสู่ระดับสากล
          </p>
          <v-divider class="my-6"></v-divider>
          <h2 class="text-h5 mb-4 font-montserrat text-hom-thai-primary">Corporate Vision (วิสัยทัศน์)</h2>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #555;">
            “หอมไทย” จะเป็นผู้นำด้านผลิตภัณฑ์ยาดมสมุนไพรในเอเชีย ภายใน 5 ปี
          </p>
        </v-sheet>
      </v-col>

      <v-col cols="12" md="6">
        <v-sheet 
          color="cream-medium" 
          class="pa-6 pa-md-8 rounded-lg h-100 elevation-2 d-flex flex-column"
        >
          <h2 class="text-h5 text-center mb-5 font-montserrat text-hom-thai-primary">Corporate Values (ค่านิยมหลัก)</h2>
          <v-list class="transparent-list" dense>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-lightbulb-on-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Creative Initiative:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">ความคิดริเริ่มและสร้างสรรค์สิ่งใหม่ ๆ ที่มีคุณค่า</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-handshake-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Teamwork & Cooperation:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">การทำงานร่วมกันเพื่อบรรลุเป้าหมาย</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-shield-check-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Integrity:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">ความซื่อสัตย์และยึดมั่นในหลักการ</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item class="mb-3">
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-rocket-launch-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Achievement Orientation:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">มีแรงผลักดันเพื่อความสำเร็จ</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
            <v-list-item>
              <v-list-item-icon class="mr-4">
                <v-icon size="28" color="hom-thai-primary">mdi-star-four-points-outline</v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title class="font-weight-bold text-body-1 font-poppins">Excellence:</v-list-item-title>
                <v-list-item-subtitle class="text-body-2 font-sarabun">การพัฒนาคุณภาพอย่างต่อเนื่อง</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
          </v-list>
        </v-sheet>
      </v-col>
    </v-row>

    <v-sheet 
      color="cream-medium" 
      class="pa-6 pa-md-10 mb-10 rounded-lg elevation-4"
    >
      <v-row align="center">
        <v-col cols="12" md="6">
          <h2 class="text-h5 text-md-h4 mb-4 font-montserrat text-hom-thai-primary">
            จุดแข็งของเรา
          </h2>
          <p class="text-body-1 font-poppins" style="line-height: 1.8; color: #444;">
            เราสร้างความแตกต่างจากคู่แข่งในตลาดโดยการมีทางเลือกให้ผู้ซื้อได้ Customized 

กลิ่นของผลิตภัณฑ์และ บรรจุภัณฑ์ตามความต้องการ ของตนเอง ไม่ได้ขายแค่ตัวสินค้า แต่ยังขาย "ประสบการณ์" และ "เรื่องราว" ที่ลูกค้ามีส่วนร่วมในการสร้าง ทำให้ผลิตภัณฑ์มีมูลค่าทางจิตใจ สูงขึ้นซึ่งตอบสนองเทรนด์ของผู้บริโภคยุคใหม่ที่ต้องการผลิตภัณฑ์ที่สะท้อนความเป็นตัวเองและใส่ใจ ในรายละเอียด   

และเราได้ ใช้ AI ในการช่วยลูกค้าปรับแต่งกลิ่น และ เทคโนโลยีติดตามพฤติกรรมการซื้อของลูกค้า แล้วก็เอามาวิเคราะห์ว่าเราจะขายสินค้า หรือ สร้าง Brand Awareness 
          </p>
        </v-col>
        <v-col cols="12" md="6">
          <v-img 
            src="../public/str.jpeg" 
            alt="จุดแข็ง" 
            
            class="rounded-lg elevation-2"
            contain
          ></v-img>
        </v-col>
      </v-row>
    </v-sheet>

  </v-container>
</template>

<script setup>
// ไม่มี logic เพิ่มเติมในตอนนี้
</script>

<style scoped>
/*
  สไตล์ที่กำหนดแบบ scoped จะมีผลเฉพาะใน Component นี้เท่านั้น
  เพื่อให้มั่นใจว่าฟอนต์และสีที่ใช้ใน Theme มีผลทั่วทั้งแอปพลิเคชัน
  ควรจัดการผ่าน Global CSS/SCSS หรือ Nuxt Config
*/

/*
  หากต้องการใช้ฟอนต์ Montserrat, Poppins, Sarabun ต้องแน่ใจว่าได้ตั้งค่า
  Google Fonts module และ Global CSS (assets/main.scss) ตามที่แนะนำไปก่อนหน้านี้แล้ว
*/

.font-montserrat {
  font-family: 'Montserrat', 'Sarabun', sans-serif !important;
}

.font-poppins {
  font-family: 'Poppins', 'Sarabun', sans-serif !important;
}

.font-sarabun {
  font-family: 'Sarabun', sans-serif !important;
}

/* ปรับระยะห่างระหว่าง v-list-item */
.transparent-list .v-list-item {
  background-color: transparent !important; /* ทำให้พื้นหลังโปร่งใส */
  padding-left: 0;
  padding-right: 0;
}

/* เพิ่มความยืดหยุ่นให้ list item content */
.transparent-list .v-list-item-content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

/* แก้ไข gap สำหรับ flexbox ในบางเบราว์เซอร์ */
.d-flex.flex-column.gap-3 > *:not(:last-child) {
  margin-bottom: 1rem; /* ระยะห่างระหว่าง list items */
}
</style>