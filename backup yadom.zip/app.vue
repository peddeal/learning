<script setup lang="ts">
import { NuxtPage } from '#components';

</script>



<template>
  <VApp>
    <VMain>
      <NuxtLayout />
    </VMain>
  </VApp>
</template>